
import 'package:flutter/material.dart';

void main() {
  runApp(MaterialApp(
    debugShowCheckedModeBanner: false,
    home: Scaffold(
      backgroundColor: Colors.black,
      body: Center(
        child: Text(
          'Bem-vindo ao TecnoSeg!',
          style: TextStyle(color: Colors.white, fontSize: 24),
        ),
      ),
    ),
  ));
}
